/* Pipe module for OpenSCAD
 * Copyright (C) 2013 Johannes Reinhardt <jreinhardt@ist-dein-freund.de>
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 */

module roundBatteryBase(h,d){
	union(){
		//nub
		cylinder(r=d/6,h=h);
		//cell
		cylinder(r=d/2,h=0.97*h);
	}
}

function roundBatteryConn(h,location) = 
	(location == "plus")  ? [[0,0,h],[[0,0,1],[0,1,0]]] :
	(location == "minus") ? [[0,0,0],[[0,0,1],[0,1,0]]] :
	"Error";
